package com.example.progettotm;

import static com.example.progettotm.R.layout.activity_main;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    //Connection conn;
    //String ConnectionResult = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_main);

    }

    public void GetTextFromSQL(View v)
    {
        /*TextView textdb = (TextView) findViewById(R.id.textfromdb);
        TextView textdb2 = (TextView) findViewById(R.id.textfromdb2);

        EditText indirizzo = (EditText) findViewById(R.id.txt_ip);

        try
        {
            ConnectionHelper connectionHelper = new ConnectionHelper();
            conn = connectionHelper.connectionclass();
            //indirizzo.getText().toString()

            if(conn!=null)
            {
                String quer = "Select * from Prodotti";
                Statement sta = conn.createStatement();
                ResultSet rs = sta.executeQuery(quer);

                String query="INSERT INTO Prodotti (idprodotto, quantita, nome) VALUES (?,?,?)";
                PreparedStatement st=conn.prepareStatement(query);
                st.setString(1, "100528");
                st.setString(2, "24");
                st.setString(3, "Carne");
                st.executeQuery();

                rs.next();
                textdb.setText(rs.getString(1));

                while (rs.next())
                {
                    textdb2.setText(rs.getString(3));
                }
            }
            else
            {
                System.out.println("Server non attivo. Riprovare più tardi...");
                textdb.setText("Non riesco a raggiungere il server. Provare più tardi...");
                //ConnectionResult = "Check Connection";
            }
        }
        catch (Exception ex) {
        }*/
    }

    public void openAccesso(View v)
    {
        Intent intent = new Intent(this, Accesso.class);
        startActivity(intent);
    }

    public void openRegistrazione(View v)
    {
        Intent intent = new Intent(this, Registrazione.class);
        startActivity(intent);
    }
}