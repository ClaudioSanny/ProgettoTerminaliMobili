package com.example.progettotm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Accesso extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accesso);

        ConnectionHelper connectionHelper = new ConnectionHelper();
        Connection conn = connectionHelper.connectionclass();

        ImageButton buttonindietro = findViewById(R.id.accessreturn);
        buttonindietro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

        Button accedi = findViewById(R.id.buttonaccedi2);
        accedi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                accedi(conn);
            }
        });
    }

    public void openMainActivity()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void accedi(Connection conn)
    {
        EditText id = findViewById(R.id.idutente);
        EditText password = findViewById(R.id.password);
        TextView messaggioerrore = findViewById(R.id.errormessage);

        if(id.getText().toString().equals("") || password.getText().toString().equals(""))
        {
            messaggioerrore.setText("id o password errati");
        }
        else
        {
            String quer = "Select * from Utenti Where idutente = '" + id.getText().toString() + "'";
            try {
                Statement sta = conn.createStatement();
                ResultSet rs = sta.executeQuery(quer);
                rs.next();
                if(rs.getString(2).equals(password.getText().toString()))
                    openNegozio(rs.getString(3), rs.getString(4));
                else
                    messaggioerrore.setText("id o password errati");
            }
            catch (Exception ex) {
                //Log.e("Errore ", ex.getMessage());
                messaggioerrore.setText("id o password errati");
            }
        }
    }

    private void openNegozio(String nome, String residenza)
    {
        Intent intent = new Intent(this, Negozio.class);
        intent.putExtra("nome", nome);
        intent.putExtra("residenza", residenza);
        startActivity(intent);
    }
}