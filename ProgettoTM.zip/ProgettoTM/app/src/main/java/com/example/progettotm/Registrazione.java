package com.example.progettotm;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Registrazione extends AppCompatActivity {

    ImageView correctsymbol;
    ImageView wrongsymbol;

    int count = -1;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrazione);

        ImageView serverinattivo = findViewById(R.id.serverinattivo);
        serverinattivo.setVisibility(View.INVISIBLE);

        correctsymbol  = findViewById(R.id.correctsymbol);
        correctsymbol.setVisibility(View.INVISIBLE);
        wrongsymbol = findViewById(R.id.wrongsymbol);
        wrongsymbol.setVisibility(View.INVISIBLE);

        ConnectionHelper connectionHelper = new ConnectionHelper();
        Connection conn = connectionHelper.connectionclass();

        if(conn == null)
        {
            serverinattivo.setVisibility(1);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    openMainActivity();
                }
            }, 5000);
        }

        ImageButton buttonindietro = findViewById(R.id.registrazionereturn);
        buttonindietro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

        Button buttonverifica = findViewById(R.id.verificabutton);
        buttonverifica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verificadisponibilita(conn);
            }
        });

        Button buttonregistrazione = findViewById(R.id.registratibutton);
        buttonregistrazione.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                registrazione(conn);
            }
        });

    }

    public void openMainActivity()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void verificadisponibilita(Connection conn)
    {
        correctsymbol.setVisibility(View.INVISIBLE);
        wrongsymbol.setVisibility(View.INVISIBLE);

        correctsymbol  = findViewById(R.id.correctsymbol);
        wrongsymbol = findViewById(R.id.wrongsymbol);

        EditText idinput = (EditText) findViewById(R.id.idinput);
        String idtesto = idinput.getText().toString();

        try {
            if (conn != null) {
                String quer = "Select * from Utenti Where idutente = '" + idtesto + "'";
                Statement sta = conn.createStatement();
                ResultSet rs = sta.executeQuery(quer);

                count = 0;
                while (rs.next()) {
                    count++;
                }

                if (count > 0) {
                    wrongsymbol.setVisibility(View.VISIBLE);
                } else {
                    correctsymbol.setVisibility(View.VISIBLE);
                }
            } else {
                System.out.println("Server non attivo. Riprovare più tardi...");
            }
        }
        catch (Exception ex) {
            Log.e("Errore ", ex.getMessage());
        }
    }

    public void registrazione(Connection conn)
    {
        TextView texterror = findViewById(R.id.texterror);

        if(count != 0)
        {
            texterror.setText("Verifica che l'id non sia già in uso");
        }
        else
        {
            EditText password = findViewById(R.id.passwordinput);
            if(password.getText().toString().equals(""))
                texterror.setText("Scegli una password");
            else
            {
                EditText nome = findViewById(R.id.nome);
                EditText residenza = findViewById(R.id.residenza);
                if(nome.getText().toString().equals(""))
                    texterror.setText("Inserisci il tuo nome");
                else
                {
                    EditText idinput = (EditText) findViewById(R.id.idinput);
                    String idtesto = idinput.getText().toString();

                    try
                    {
                        String query="INSERT INTO Utenti (idutente, password, nomeutente, residenza) VALUES (?,?,?,?)";
                        PreparedStatement st=conn.prepareStatement(query);
                        st.setString(1, idtesto);
                        st.setString(2, password.getText().toString());
                        st.setString(3, nome.getText().toString());
                        st.setString(4, residenza.getText().toString());
                        st.executeQuery();
                    }
                    catch (SQLException e)
                    {
                        e.printStackTrace();
                    }

                    setContentView(R.layout.registrazioneeffettuata);

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            openMainActivity();
                        }
                        }, 5000);
                }
            }
        }
    }
}