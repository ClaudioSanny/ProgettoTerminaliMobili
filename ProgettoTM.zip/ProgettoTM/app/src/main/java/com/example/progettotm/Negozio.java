package com.example.progettotm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Negozio extends AppCompatActivity {

    Connection conn;
    ConnectionHelper connectionHelper = new ConnectionHelper();

    private int[] quantitafinale = new int[100];
    private String[] nomeprodotti = new String[100];

    private String nome;
    private String residenza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_negozio);

        Bundle datipassati = getIntent().getExtras();
        nome = datipassati.getString("nome");
        residenza = datipassati.getString("residenza");

        ImageButton buttonindietro = findViewById(R.id.negozioreturn);
        buttonindietro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

        EditText quantita = (EditText)findViewById(R.id.quantia);
        quantita.setVisibility(View.INVISIBLE);

        conn = connectionHelper.connectionclass();

        TextView quantitaprodotti = (TextView) findViewById(R.id.quantitaprodotti);
        quantitaprodotti.setVisibility(View.INVISIBLE);

        int[] scelte = new int[100];

        ListView mylist = (ListView) findViewById(R.id.listaprodotti);

        Button buttonavanti = findViewById(R.id.buttonavanti);
        buttonavanti.setVisibility(View.INVISIBLE);

        Button buttonconferma = findViewById(R.id.buttonconferma);
        buttonconferma.setVisibility(View.VISIBLE);
        buttonconferma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                buttonconferma.setVisibility(View.INVISIBLE);
                buttonavanti.setVisibility(View.VISIBLE);

                int indice = 0;
                boolean fine = false;

                String quer = "Select * from Prodotti";
                Statement sta = null;
                try {
                    sta = conn.createStatement();
                    ResultSet rs = sta.executeQuery(quer);

                    conferma(scelte, mylist, quantitaprodotti, buttonavanti, rs, indice, fine, quantita);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

            }
        });

        try
        {
            String quer = "Select * from Prodotti";
            Statement sta = conn.createStatement();
            ResultSet rs = sta.executeQuery(quer);

            final ArrayList <String> listp = new ArrayList<String>();
            while(rs.next())
            {
                listp.add(rs.getString(3));
            }

            // creo e istruisco l'adattatore
            final ArrayAdapter <String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_checked, listp);
            // inietto i dati
            mylist.setAdapter(adapter);

            mylist.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

            mylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if(scelte[position] != 0)
                        scelte[position] = 0;
                    else
                        scelte[position] = 1;
                }
            });
        }
        catch (Exception ex) { }
    }

    private void conferma(int[] scelte, ListView mylist, TextView quantitaprodotti, Button buttonavanti, ResultSet rs,
                          int indice, boolean fine, EditText quantita)
    {
        mylist.setVisibility(View.INVISIBLE);
        quantitaprodotti.setVisibility(View.VISIBLE);
        quantita.setVisibility(View.VISIBLE);
        quantita.setText("");

        int scorte = 0;

        PreparedStatement ps = null;

        if(fine == true)
        {
            try
            {
                for(int i = 0; i<100; i++) {
                    if(scelte[i] != 0) {
                        ps = conn.prepareStatement(
                                "UPDATE Prodotti SET quantita = ? WHERE nome = ?");

                        ps.setInt(1, quantitafinale[i]);
                        ps.setString(2, nomeprodotti[i]);

                        ps.executeUpdate();
                        ps.close();
                    }
                }
            }
            catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            quantita.setVisibility(View.INVISIBLE);
            quantitaprodotti.setText("L'ordine sarà inviato a "+ nome + " in " + residenza);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    openMainActivity();
                }
            }, 5000);
        }
        else {
            try {
                while (scelte[indice] != 1 && rs.next()) {
                    indice = indice + 1;
                }
                rs.next();
                if (scelte[indice] == 1)
                {
                    nomeprodotti[indice] = rs.getString(3);
                    quantitaprodotti.setText(rs.getString(3) + " - MAX: " + rs.getString(2) + " - MIN: 1");
                    scorte = rs.getInt(2);
                }
                else {
                    quantita.setVisibility(View.INVISIBLE);
                    quantitaprodotti.setText("CONFERMI ORDINE?");
                    fine = true;
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        int finalIndice = indice;
        boolean finalFine = fine;
        int finalScorte = scorte;
        buttonavanti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(finalFine != true) {
                    if(Integer.parseInt(quantita.getText().toString()) < finalScorte)
                        quantitafinale[finalIndice] = finalScorte - Integer.parseInt(quantita.getText().toString());
                    else
                        quantitafinale[finalIndice] = 0;
                }
                conferma(scelte, mylist, quantitaprodotti, buttonavanti, rs, finalIndice+1, finalFine, quantita);
            }
        });
    }

    public void openMainActivity()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}