package com.example.progettotm;

import static com.example.progettotm.R.layout.activity_main;

import static java.net.Inet6Address.*;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.location.Address;
import android.os.StrictMode;
import android.util.Log;
import android.widget.EditText;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionHelper {

    Connection con;
    String uname, pass, ip, port, database;

    @SuppressLint("NewApi")

    public Connection connectionclass()
    {

        ip = "10.0.2.2";
        database = "negozio_tm";
        uname="sa";
        pass="0124";
        port="1433";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Connection connection = null;
        String ConnectionURL = null;

        try
        {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionURL= "jdbc:jtds:sqlserver://"+ ip + ":"+ port+";"+ "databasename="+ database+";user="+uname+";password="+pass+";";

            //DriverManager.setLoginTimeout(10);
            connection = DriverManager.getConnection(ConnectionURL);

            System.out.println("Connessione effettuata");
        }
        catch (Exception ex)
        {
            Log.e("Errore ", ex.getMessage());
        }

        return connection;
    }
}